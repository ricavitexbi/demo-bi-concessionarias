# 🎨 GUIA VISUAL DA DEMO - Sistema BI Concessionárias

## 📱 Prévia da Interface

### Navegação Principal (Sidebar)

```
┌─────────────────────────────┐
│ 🚗 Sistema BI Automotivo    │
│ Powered by Viv.IA           │
├─────────────────────────────┤
│                             │
│ ○ 📊 Dashboard Principal    │
│ ○ 🤖 Assistente Viv.IA      │
│ ○ 📈 Previsão de Demanda    │
│ ○ 🏪 Análise de Estoque     │
│ ○ 💰 Precificação           │
│ ○ 👥 Análise de Clientes    │
│ ○ ⚠️ Alertas                │
│                             │
├─────────────────────────────┤
│ 📌 Demo do Sistema          │
│ • 600 clientes              │
│ • 375 vendas (24 meses)     │
│ • 60 veículos em estoque    │
└─────────────────────────────┘
```

---

## 1️⃣ Dashboard Principal - Layout

```
╔════════════════════════════════════════════════════════════════╗
║          📊 Dashboard Executivo - Visão Geral                  ║
╚════════════════════════════════════════════════════════════════╝

┌──────────────┬──────────────┬──────────────┬──────────────┐
│ 🚗 Estoque   │ 📅 Vendas    │ 💹 Margem    │ ⏱️ Tempo     │
│              │              │              │              │
│     60       │     18       │   16.4%      │   51 dias    │
│ R$ 4.4M      │ R$ 1.2M      │ R$ 4.4M      │ 5 críticos   │
└──────────────┴──────────────┴──────────────┴──────────────┘

┌─────────────────────────────────┬─────────────────────────────┐
│  📈 Evolução de Vendas Mensal   │  🎯 Vendas por Categoria    │
│                                 │                             │
│  [Gráfico de Barras Interativo]│  [Gráfico de Pizza]         │
│                                 │                             │
│  • Hover com detalhes           │  • Popular: 35%             │
│  • Zoom in/out                  │  • Médio: 26%               │
│  • Pan para navegar             │  • SUV: 27%                 │
│                                 │  • Premium: 12%             │
└─────────────────────────────────┴─────────────────────────────┘

╔═══════════════════════════════════════════════════════════════╗
║             🏢 Performance por Concessionária                  ║
╠═══════════════════════════════════════════════════════════════╣
║ Concessionária        │ Vendas │ Receita      │ Lucro        ║
║ AutoPrime Seminovos   │  124   │ R$ 7.0M      │ R$ 1.0M      ║
║ MotorMax Veículos     │  123   │ R$ 11.2M     │ R$ 1.6M      ║
║ Premium Auto Center   │  128   │ R$ 13.4M     │ R$ 1.8M      ║
╚═══════════════════════════════════════════════════════════════╝

┌─────────────────────────────────┬─────────────────────────────┐
│  🏆 Top 10 Modelos Mais Vendidos│  📊 Distribuição de Estoque │
│                                 │      por Status             │
│  [Gráfico de Barras Horizontal]│  [Gráfico de Barras]        │
│                                 │                             │
│  1. Onix                        │  • Novo (verde)             │
│  2. Creta                       │  • Normal (azul)            │
│  3. HB20                        │  • Atenção (laranja)        │
│  ...                            │  • Crítico (vermelho)       │
└─────────────────────────────────┴─────────────────────────────┘
```

**Cores do Dashboard:**
- Fundo: Branco/Cinza claro
- Headers: Gradiente Roxo/Azul
- Métricas: Cards com borda azul
- Gráficos: Paleta profissional (steelblue, coral, etc)

---

## 2️⃣ Assistente Viv.IA - Layout

```
╔════════════════════════════════════════════════════════════════╗
║          🤖 Assistente Conversacional Viv.IA                   ║
╚════════════════════════════════════════════════════════════════╝

Faça perguntas em linguagem natural!

O assistente Viv.IA pode responder sobre:
• 📦 Estoque de veículos
• 💰 Análise de vendas  
• 💵 Sugestões de preço
• ⚠️ Alertas importantes
• 📈 Previsões de demanda

┌────────────────────────────────────────────────────────────────┐
│ 💡 Experimente perguntar:                                      │
│                                                                │
│  [📦 Quantos veículos tenho?] [🏆 Mais vendidos?] [⚠️ Alertas?]│
└────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│ Sua pergunta: _______________________________________________  │
└────────────────────────────────────────────────────────────────┘

╔════════════════════════════════════════════════════════════════╗
║  👤 Você:                                                      ║
║  Quantos veículos tenho em estoque?                            ║
╚════════════════════════════════════════════════════════════════╝

╔════════════════════════════════════════════════════════════════╗
║  🤖 Viv.IA:                                                    ║
║                                                                ║
║  📦 ESTOQUE ATUAL:                                             ║
║                                                                ║
║  Total de veículos: 60                                         ║
║  Capital investido: R$ 4.418.125,00                            ║
║                                                                ║
║  Por categoria:                                                ║
║  - Popular: 30 unidades                                        ║
║  - Médio: 18 unidades                                          ║
║  - Suv: 9 unidades                                             ║
║  - Premium: 3 unidades                                         ║
╚════════════════════════════════════════════════════════════════╝
```

**Design Conversacional:**
- Mensagens do usuário: Fundo azul claro, alinhadas à direita
- Respostas Viv.IA: Fundo cinza claro, alinhadas à esquerda
- Botões de sugestão: Bordas arredondadas, hover effect
- Emoji para personalidade: 👤 (usuário) e 🤖 (assistente)

---

## 3️⃣ Previsão de Demanda - Layout

```
╔════════════════════════════════════════════════════════════════╗
║      📈 Previsão de Demanda com Machine Learning               ║
╚════════════════════════════════════════════════════════════════╝

🤖 Modelo treinado com 24 meses de histórico + indicadores macro

┌─────────────────────────────────────────┬───────────────────────┐
│   📊 Histórico vs Previsão              │   🎯 Previsões        │
│                                         │                       │
│   [Gráfico de Linha Interativo]        │   ┌─────────────────┐ │
│                                         │   │ Mês +1          │ │
│   • Linha azul: Vendas Reais            │   │   16 unidades   │ │
│   • Linha tracejada: Modelo Fitted      │   │   ± 2 (10%)     │ │
│   • Linha vermelha: Previsão Futura     │   └─────────────────┘ │
│                                         │                       │
│   Performance do Modelo:                │   ┌─────────────────┐ │
│   • 24 meses de treino                  │   │ Mês +2          │ │
│   • MAE: 1.01 unidades                  │   │   17 unidades   │ │
│   • MAPE: 6.15%                         │   │   ± 2 (10%)     │ │
│   • Acurácia: 93.9%                     │   └─────────────────┘ │
│                                         │                       │
│   Features utilizadas:                  │   ┌─────────────────┐ │
│   • Tendência temporal                  │   │ Mês +3          │ │
│   • Taxa Selic                          │   │   16 unidades   │ │
│   • Confiança do Consumidor             │   │   ± 2 (10%)     │ │
│                                         │   └─────────────────┘ │
└─────────────────────────────────────────┴───────────────────────┘

╔════════════════════════════════════════════════════════════════╗
║          🎨 Recomendação de Mix por Categoria                  ║
╠════════════════════════════════════════════════════════════════╣
║   🎯 Popular  │  🎯 Médio    │  🎯 SUV      │  🎯 Premium     ║
║               │              │              │                 ║
║   6 un.       │   4 un.      │   4 un.      │   2 un.        ║
║   35% total   │   26% total  │   27% total  │   12% total    ║
╚════════════════════════════════════════════════════════════════╝
```

**Elementos Visuais:**
- Gráfico principal: Grande, destaque central
- Métricas de performance: Cards com ícones
- Previsões futuras: Highlight em vermelho no gráfico
- Mix recomendado: Cards coloridos por categoria

---

## 4️⃣ Análise de Estoque - Layout

```
╔════════════════════════════════════════════════════════════════╗
║               🏪 Análise Detalhada de Estoque                  ║
╚════════════════════════════════════════════════════════════════╝

┌──────────────────┬──────────────────┬──────────────────────────┐
│ Concessionária:  │ Categoria:       │ Status:                  │
│ [▼ Todas       ] │ [▼ Todas       ] │ [▼ Todos               ] │
└──────────────────┴──────────────────┴──────────────────────────┘

┌──────────────┬──────────────┬──────────────┬──────────────────┐
│ 🚗 Veículos  │ 💰 Valor     │ 📅 Tempo     │ 💎 Ticket Médio  │
│     60       │  R$ 4.4M     │   51 dias    │   R$ 74k         │
└──────────────┴──────────────┴──────────────┴──────────────────┘

┌─────────────────────────────────────┬─────────────────────────┐
│  ⏱️ Distribuição por Tempo Pátio    │  💰 Valor por Categoria │
│                                     │                         │
│  [Histograma Colorido por Status]  │  [Gráfico de Barras]    │
│                                     │                         │
│  • Verde: Novos (<30d)              │  • Popular: R$ 2.2M     │
│  • Azul: Normal (30-60d)            │  • Médio: R$ 1.3M       │
│  • Laranja: Atenção (60-90d)        │  • SUV: R$ 661k         │
│  • Vermelho: Crítico (>90d)         │  • Premium: R$ 222k     │
└─────────────────────────────────────┴─────────────────────────┘

╔════════════════════════════════════════════════════════════════╗
║                  📋 Inventário Detalhado                       ║
╠════════════════════════════════════════════════════════════════╣
║ Modelo  │ Ano  │ Cor    │ KM    │ Dias  │ Preço      │ Status ║
╠════════════════════════════════════════════════════════════════╣
║ Onix    │ 2022 │ Branco │ 35k   │  45   │ R$ 75.500  │ Normal ║
║ Compass │ 2023 │ Preto  │ 28k   │  95   │ R$ 165.000 │ CRÍTICO║
║ HB20    │ 2021 │ Prata  │ 42k   │  23   │ R$ 68.900  │ Novo   ║
║ ...     │ ...  │ ...    │ ...   │  ...  │ ...        │ ...    ║
╚════════════════════════════════════════════════════════════════╝
              [Linhas críticas destacadas em vermelho]
```

**Interatividade:**
- Filtros: Dropdowns responsivos
- Tabela: Ordenável por coluna, scroll horizontal
- Gráficos: Hover com detalhes, zoom, download
- Cores: Status visual imediato

---

## 5️⃣ Precificação Inteligente - Layout

```
╔════════════════════════════════════════════════════════════════╗
║              💰 Sistema de Precificação Dinâmica               ║
╚════════════════════════════════════════════════════════════════╝

Algoritmo de Precificação Baseado em:
• ⏱️ Tempo em pátio  • 📊 Valores Fipe  • 🎯 Performance  • 📈 Demanda

┌────────────────────────────────────────────────────────────────┐
│ Selecione um veículo:                                          │
│ [▼ Onix 2022 - Branco (VEI0001)                             ] │
└────────────────────────────────────────────────────────────────┘

┌─────────────────────────────┬──────────────────────────────────┐
│  📋 Informações do Veículo  │  💡 Análise de Precificação      │
│                             │                                  │
│  Modelo: Onix               │  ┌────────────────────────────┐  │
│  Ano: 2022                  │  │ 💵 Preço Atual             │  │
│  Cor: Branco                │  │    R$ 75.500               │  │
│  KM: 35.000                 │  └────────────────────────────┘  │
│  Combustível: Flex          │                                  │
│  Estado: Bom                │  ┌────────────────────────────┐  │
│  Concessionária:            │  │ 💎 Preço Sugerido          │  │
│    AutoPrime Seminovos      │  │    R$ 73.235               │  │
│                             │  │    ↓ -3.0%                 │  │
│  ───────────────────────    │  └────────────────────────────┘  │
│                             │                                  │
│  Entrada: 15/08/2024        │  ┌────────────────────────────┐  │
│  Dias em pátio: 45 dias     │  │ 📊 Valor Fipe              │  │
│  Status: Normal             │  │    R$ 72.000               │  │
│                             │  └────────────────────────────┘  │
│                             │                                  │
│                             │  ⚡ Considere pequeno desconto    │
│                             │                                  │
│                             │  📊 Análise Detalhada:           │
│                             │  • Margem Atual: 18.5%           │
│                             │  • Margem Sugerida: 15.2%        │
│                             │  • Desconto: 3.0%                │
│                             │  • Lucro Estimado: R$ 9.685      │
│                             │                                  │
│                             │  🎯 Racional da Sugestão:        │
│                             │  O algoritmo considera que       │
│                             │  veículos com 45 dias em pátio   │
│                             │  apresentam custo de oportunidade│
│                             │  moderado. Um ajuste de 3.0%     │
│                             │  pode acelerar a venda mantendo  │
│                             │  margem saudável de 15.2%.       │
└─────────────────────────────┴──────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│           📈 Comparação Visual de Valores                      │
│                                                                │
│  [Gráfico de Barras Comparativo]                              │
│                                                                │
│  Valor Compra  │████████████░░░░░░░░░░░   R$ 64.000           │
│  Preço Atual   │████████████████████░░░░░  R$ 75.500           │
│  Preço Sugerido│███████████████████░░░░░░  R$ 73.235           │
│  Valor Fipe    │██████████████████░░░░░░░  R$ 72.000           │
└────────────────────────────────────────────────────────────────┘
```

**Elementos de Design:**
- Cards de métricas: Destaque visual para preços
- Status colorido: Verde/Amarelo/Vermelho conforme urgência
- Gráfico comparativo: Barras horizontais com cores distintas
- Racional explicativo: Texto claro e educativo

---

## 6️⃣ Análise de Clientes - Layout

```
╔════════════════════════════════════════════════════════════════╗
║              👥 Análise de Base de Clientes                    ║
╚════════════════════════════════════════════════════════════════╝

┌──────────────┬──────────────┬──────────────┬──────────────────┐
│ 👥 Total     │ 💰 Renda     │ 🎂 Idade     │ 🔄 Já Compraram  │
│   600        │  R$ 6.728    │   43 anos    │  180 (30%)       │
└──────────────┴──────────────┴──────────────┴──────────────────┘

┌─────────────────────────────────────┬─────────────────────────┐
│  📊 Distribuição por Segmento       │  💰 Distribuição Renda  │
│                                     │                         │
│  [Gráfico de Pizza]                 │  [Histograma]           │
│                                     │                         │
│  • Econômico: 15%                   │  • Pico: R$ 4k-8k       │
│  • Médio: 48%                       │  • Média: R$ 6.7k       │
│  • Alto: 28%                        │  • Variação por segmento│
│  • Premium: 9%                      │                         │
└─────────────────────────────────────┴─────────────────────────┘

┌─────────────────────────────────────┬─────────────────────────┐
│  🎯 Preferência por Categoria       │  💳 Forma de Pagamento  │
│                                     │                         │
│  [Gráfico de Barras]                │  [Gráfico de Pizza]     │
│                                     │                         │
│  • Popular: 280 clientes            │  • Financiado: 75%      │
│  • Médio: 180 clientes              │  • À Vista: 25%         │
│  • SUV: 110 clientes                │                         │
│  • Premium: 30 clientes             │                         │
└─────────────────────────────────────┴─────────────────────────┘

╔════════════════════════════════════════════════════════════════╗
║                   💡 Insights Principais                       ║
╠════════════════════════════════════════════════════════════════╣
║  🎯 Público-Alvo Principal                                     ║
║  Segmento Médio representa a maior fatia da base de clientes.  ║
║  Concentre campanhas e estoque para este perfil.               ║
╠════════════════════════════════════════════════════════════════╣
║  🚗 Categoria Mais Procurada                                   ║
║  Veículos da categoria popular são os mais desejados.          ║
║  Mantenha estoque adequado desta categoria.                    ║
╠════════════════════════════════════════════════════════════════╣
║  💳 Financiamento                                              ║
║  75% dos clientes preferem financiamento.                      ║
║  Tenha parcerias bancárias competitivas.                       ║
╚════════════════════════════════════════════════════════════════╝
```

**Design de Insights:**
- Cards coloridos: Azul (info), Verde (sucesso), Amarelo (atenção)
- Ícones grandes: Visual impact
- Texto conciso: Direto ao ponto
- Gráficos coordenados: Mesma paleta de cores

---

## 7️⃣ Alertas e Recomendações - Layout

```
╔════════════════════════════════════════════════════════════════╗
║           ⚠️ Central de Alertas e Recomendações                ║
╚════════════════════════════════════════════════════════════════╝

┌────────────────────────────────────────────────────────────────┐
│                    🚨 Alertas Críticos                         │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  🚨 5 veículos em situação CRÍTICA                             │
│                                                                │
│  Capital preso: R$ 735.325,00                                  │
│  Veículos parados há mais de 90 dias.                          │
│                                                                │
│  ✅ Ação recomendada:                                          │
│  Reduzir preços urgentemente para liquidar estoque             │
│                                                                │
└────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│                   ⚡ Alertas de Atenção                         │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  ⚡ Estoque baixo: Onix                                         │
│  Apenas 1 unidade em estoque. Vendeu 8 no último mês.          │
│  ✅ Ação: Comprar mais unidades de Onix para atender demanda   │
│                                                                │
│  ⚡ Estoque baixo: Creta                                        │
│  Apenas 1 unidade em estoque. Vendeu 6 no último mês.          │
│  ✅ Ação: Comprar mais unidades de Creta para atender demanda  │
│                                                                │
│  📉 Margem média abaixo do ideal                               │
│  Margem média recente: 11.8% (meta: >15%)                      │
│  ✅ Ação: Revisar estratégia de precificação                   │
│                                                                │
└────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│              💡 Informações e Oportunidades                    │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  📊 Desempenho desigual entre concessionárias                  │
│  Premium Auto Center vendendo 50% mais que AutoPrime           │
│  ✅ Ação: Investigar fatores de sucesso e replicar            │
│                                                                │
└────────────────────────────────────────────────────────────────┘

╔════════════════════════════════════════════════════════════════╗
║              🎯 Recomendações Estratégicas                     ║
╠════════════════════════════════════════════════════════════════╣
║  📈 Aumentar Faturamento     │  💰 Reduzir Custos              ║
║                              │                                 ║
║  1. Precificação Dinâmica    │  1. Liquidação de Críticos      ║
║     +R$ 324k/ano             │     +R$ 39k imediato            ║
║                              │                                 ║
║  2. Otimização de Mix        │  2. Compra Inteligente          ║
║     +R$ 180k/ano             │     Redução dead stock: -70%    ║
║                              │                                 ║
║  3. Redução Tempo Pátio      │  3. Negociação Bancária         ║
║     +R$ 140k/ano             │     75% dos clientes financiam  ║
╚════════════════════════════════════════════════════════════════╝

┌────────────────────────────────────────────────────────────────┐
│                   💎 ROI ESTIMADO DO SISTEMA                   │
│                                                                │
│  Ganhos Anuais Estimados: R$ 503.000                          │
│  • Otimização de margem: +R$ 324k                              │
│  • Redução tempo pátio: +R$ 140k                               │
│  • Redução dead stock: +R$ 39k                                 │
│                                                                │
│  Investimento Sistema: R$ 14.400/ano (R$ 1.200/mês)           │
│                                                                │
│  ROI: 34.9x | Payback: < 1 mês                                │
└────────────────────────────────────────────────────────────────┘
```

**Código de Cores para Alertas:**
- 🚨 Crítico: Fundo vermelho claro (#ffebee)
- ⚡ Atenção: Fundo laranja claro (#fff3e0)
- 💡 Info: Fundo verde claro (#e8f5e9)
- Bordas: Esquerda espessa com cor correspondente

---

## 🎨 Paleta de Cores Oficial

```css
/* Cores Primárias */
Azul Principal:    #1f77b4
Roxo Destaque:     #667eea → #764ba2 (gradiente)
Verde Sucesso:     #4caf50
Laranja Atenção:   #ff9800
Vermelho Crítico:  #f44336

/* Cores Secundárias */
Cinza Claro:       #f0f2f6
Cinza Médio:       #cccccc
Coral:             #ff6b6b
Steelblue:         #4682b4

/* Backgrounds */
Card Normal:       #ffffff
Card Destaque:     #f0f2f6
Alerta Crítico:    #ffebee
Alerta Atenção:    #fff3e0
Alerta Info:       #e8f5e9
```

---

## 📱 Responsividade

A demo é **100% responsiva** e funciona em:

- **Desktop**: Layout em colunas, gráficos lado a lado
- **Tablet**: Layout adaptado, colunas empilham
- **Mobile**: Layout vertical, navegação simplificada

---

## 🎯 Pontos de Destaque na Apresentação

1. **Simplicidade**: Interface limpa, fácil de usar
2. **Interatividade**: Gráficos clicáveis, filtros dinâmicos
3. **Insights Automáticos**: Sistema identifica problemas
4. **IA Conversacional**: Natural como falar com pessoa
5. **ROI Claro**: Números concretos de retorno
6. **Dados Reais**: Métricas baseadas em histórico real

---

**Este guia visual deve ser usado como referência durante a criação de slides de apresentação ou materiais de marketing da demo.**
